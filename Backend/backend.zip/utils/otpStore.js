// utils/otpStore.js
const otpStore = new Map(); // Key: email, Value: { otp, expires }

module.exports = otpStore;
